# @s11t/runtime

## 0.1.0-canary-cc606d34273d7117a79efb910734657ff130ccce

### Minor Changes

- 2aa483d: Publish the initial S11t v0.1 runtime and CLI packages.
- cc606d3: Add request-bound render audits and public rendered-hash helpers, introduce the opt-in artifact v3
  `delimited-context-v1` boundary contract, and add machine-readable locale coverage inspection with ordered
  explicit fallbacks.

## 0.0.0

Initial development version.
