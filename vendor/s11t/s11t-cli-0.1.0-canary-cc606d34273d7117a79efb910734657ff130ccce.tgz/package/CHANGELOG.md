# @s11t/cli

## 0.1.0-canary-cc606d34273d7117a79efb910734657ff130ccce

### Minor Changes

- 2aa483d: Publish the initial S11t v0.1 runtime and CLI packages.
- cc606d3: Add request-bound render audits and public rendered-hash helpers, introduce the opt-in artifact v3
  `delimited-context-v1` boundary contract, and add machine-readable locale coverage inspection with ordered
  explicit fallbacks.

### Patch Changes

- 55a747a: Preserve file permissions during authoring v2 migration, add Git-ignored migration journal listing and
  safe purge commands, and strengthen deployment rollback and critical-file coverage verification.
- Updated dependencies [2aa483d]
- Updated dependencies [cc606d3]
  - @s11t/runtime@0.1.0-canary-cc606d34273d7117a79efb910734657ff130ccce

## 0.0.0

Initial development version.
