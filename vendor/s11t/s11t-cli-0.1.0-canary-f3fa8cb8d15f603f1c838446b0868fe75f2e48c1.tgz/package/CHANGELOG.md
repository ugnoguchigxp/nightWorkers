# @s11t/cli

## 0.1.0-canary-f3fa8cb8d15f603f1c838446b0868fe75f2e48c1

### Minor Changes

- 2aa483d: Publish the initial S11t v0.1 runtime and CLI packages.

### Patch Changes

- Updated dependencies [2aa483d]
  - @s11t/runtime@0.1.0-canary-f3fa8cb8d15f603f1c838446b0868fe75f2e48c1

## 0.0.0

Initial development version.
